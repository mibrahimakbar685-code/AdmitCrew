CREATE TABLE IF NOT EXISTS leads (
  id BIGSERIAL PRIMARY KEY,
  phone TEXT NOT NULL UNIQUE,
  full_name TEXT,
  preferred_country TEXT,
  marks_percent NUMERIC(5,2),
  ielts_score NUMERIC(3,1),
  last_reply_at TIMESTAMPTZ,
  status TEXT NOT NULL DEFAULT 'new',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS programs (
  id BIGSERIAL PRIMARY KEY,
  university TEXT NOT NULL,
  country TEXT NOT NULL,
  program TEXT NOT NULL,
  annual_fee TEXT NOT NULL,
  deadline DATE NOT NULL,
  min_marks NUMERIC(5,2) NOT NULL,
  min_ielts NUMERIC(3,1) NOT NULL,
  required_documents TEXT[] NOT NULL,
  UNIQUE(university, program)
);

CREATE TABLE IF NOT EXISTS conversations (
  id BIGSERIAL PRIMARY KEY,
  lead_id BIGINT REFERENCES leads(id),
  inbound_text TEXT,
  reply_draft TEXT,
  escalation_reason TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS documents (
  id BIGSERIAL PRIMARY KEY,
  lead_id BIGINT NOT NULL REFERENCES leads(id),
  type TEXT NOT NULL,
  storage_url TEXT,
  extracted_name TEXT,
  extracted_details JSONB NOT NULL DEFAULT '{}'::jsonb,
  result TEXT NOT NULL CHECK (result IN ('OK','Problem','Needs review')),
  reason TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS outbound_messages (
  id BIGSERIAL PRIMARY KEY,
  lead_id BIGINT NOT NULL REFERENCES leads(id),
  channel TEXT NOT NULL DEFAULT 'whatsapp',
  kind TEXT NOT NULL,
  body TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending_approval' CHECK (status IN ('pending_approval','approved','declined','sent','failed')),
  approved_by TEXT,
  approved_at TIMESTAMPTZ,
  provider_message_id TEXT,
  sent_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS outbound_messages_status_idx ON outbound_messages(status);
CREATE INDEX IF NOT EXISTS leads_last_reply_idx ON leads(last_reply_at);

INSERT INTO programs (university,country,program,annual_fee,deadline,min_marks,min_ielts,required_documents) VALUES
('University of Manchester','UK','BSc Computer Science','£32,000','2027-01-15',75,6.5,ARRAY['Passport','transcript','IELTS']),
('University of Leeds','UK','BSc Business Management','£27,000','2027-01-31',70,6.5,ARRAY['Passport','transcript','IELTS','personal statement']),
('University of Toronto','Canada','BSc Computer Science','CAD 60,000','2027-01-15',80,6.5,ARRAY['Passport','transcript','IELTS']),
('TU Munich','Germany','BSc Informatics','No tuition (about €150 a term)','2027-07-15',70,6.5,ARRAY['Passport','transcript','IELTS']),
('Monash University','Australia','Bachelor of IT','AUD 48,000','2026-11-30',70,6.0,ARRAY['Passport','transcript','IELTS'])
ON CONFLICT (university,program) DO NOTHING;
